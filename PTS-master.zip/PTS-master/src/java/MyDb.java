



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mathics
 */
public class MyDb {
    
    Connection con;
    public Connection getCon()
    {        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://dijkstra.ug.bcc.bilkent.edu.tr:3306/b_gutlygeldiyev", "b.gutlygeldiyev", "n8BDEVTm");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyDb.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        return con;
    }
    
    
    public void kullanıcıListesi() throws SQLException
    {
        
        
        if(con == null)
        {
            System.out.println("Veritabanı bağlı değil");
            con = getCon();
        }
        
            try{
                Statement stmt = con.createStatement();
                ResultSet res = stmt.executeQuery("select * from user");
                System.out.println("kullanıcılar");
                while(res.next())
                {
                    System.out.println(res.getString(1));
                }
            }catch(Exception e)
            {
                e.printStackTrace();
            }
        
    }
    
    public static void main(String[] args) throws SQLException
    {
        MyDb dbk = new MyDb();
        dbk.getCon();
        dbk.kullanıcıListesi();
    }
    public boolean kullanıcıKontrol(String kullanıcıAdı,String sifre)
    {
        if(con == null)
        {
            System.out.println("Veritabanı bağlı değil");
            con = getCon();
        }
            try{
                Statement stmt = con.createStatement();
                String query = "select pass from user where name='"+kullanıcıAdı+"'";
                ResultSet res = stmt.executeQuery(query);
                System.out.println("a");
                String sonSifre = "";
                while(res.next())
                {
                    sonSifre += res.getString(1);
                }
                
                System.out.print(sonSifre);
                return sifre.equals(sonSifre);
                
            }catch(Exception e){
                e.printStackTrace();
            }
            return false;
    }

    private ResultSet executeQuery(String select__from_user) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
