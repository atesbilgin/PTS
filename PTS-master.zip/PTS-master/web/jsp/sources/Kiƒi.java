/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deneme;


/**
 *
 * @author ASUS
 */
public class Kişi {
    
    String isim;
    String sifre;

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }
    public Kişi()
    {
        System.out.println("Kisi objesi oluştu");
        
    }
    public boolean sifreKontrol()
    {
        MyDb dbk = new MyDb();
        return dbk.kullanıcıKontrol(isim, sifre);
    }
    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }
    
}
